# AL 2000 

## General

- Pas d'accent
- En français (sauf debut des noms de méthodes)

## Attributs

- Commence par une minuscule
- Mots séparés par des Majuscules (Pas de "_")

## Méthodes

- Commence par une minuscule
- Mots séparés par des Majuscules (Pas de "_")  
Exemple de début de méthode : get / set / add / del
