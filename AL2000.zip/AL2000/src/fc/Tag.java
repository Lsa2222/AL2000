package fc;

public enum Tag {
	PEGI18,
	PEGI12,
	PEGI16,
	ACTION,
	POLICIER,
	WORLDWAR, FANTASY;
}